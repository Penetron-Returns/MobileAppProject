# @nerova/react-native

The Nerova owner companion for React Native and Expo. The account owner talks
to their companion from a bottom sheet inside your app: streaming chat, tool
steps, approval cards, WhatsApp connect and the first-run setup. The character
is the plush companion from the companion profile, and its name always comes
from that profile.

Preview `0.1.0-preview.14`. New: `<CompanionSetup>`, the go-live flow inline in your own screen, and a disconnected WhatsApp now brings the connect step back even after setup was completed (preview.13 added `<CompanionMoment>`, the inline one-exchange view with a needs-you queue, and the `action` event with undo; preview.12 added the single mic/send button with voice input and the `userBubble` colours). Targets Expo SDK 57 and React Native 0.86 with the
New Architecture. There is no custom native module. The package ships a CommonJS
build (`main`, `require`) and an ES module build (`module`, `import`), both
already transpiled, so Metro and Jest load it without extra configuration.

Companions guide: [Companions](https://app.nerova.si/docs/companions) and
[Embed a companion](https://app.nerova.si/docs/companions/embedding).

## Install

```sh
npm install ./nerova-react-native-0.1.0-preview.13.tgz
npx expo install react-native-reanimated react-native-svg react-native-webview expo-web-browser expo
```

Required peers: `react`, `react-native`, `react-native-reanimated` (4+),
`react-native-svg`.

Optional peers (`peerDependenciesMeta`), and what you lose without them:

- `react-native-webview`: draws the plush character. Without it the sheet has no
  built-in character: use `avatar="hidden"` and `renderAvatar` to draw your own.
- `expo-web-browser`: opens the WhatsApp connect in Custom Tabs (Android) or
  `ASWebAuthenticationSession` (iOS). Without it, pass your own
  `openAuthSession` to `CompanionProvider`, or connecting fails with
  `browser_unavailable`.
- `expo`: provides `expo/fetch`, which streams the reply as it arrives. Without
  it the SDK streams through `XMLHttpRequest` progress events, which works the
  same; nothing else is lost.
- `expo-audio`: records the voice input (m4a). Without it the mic is hidden, unless you pass your own
  `voiceInput.createRecorder`, `onMicPress` or `renderComposerAccessory`.
- `expo-font`: lets `font.family` skip a family that is not loaded yet. Without
  it the first family in the list is used.

**Touches at rest.** Mount the provider and the sheet once in the app shell: at rest the
SDK takes no touches from your screen. Every full-screen layer it renders is
`pointerEvents="box-none"`, the dim is not rendered at all, the closed sheet is
`pointerEvents="none"`, and only the avatar button (a 64 px circle) receives touches. With
`restAvatar="hidden"` (or a resting position off screen) the avatar, including your
`renderAvatar` content such as a WebView, is not rendered at all. The SDK renders no
`GestureHandlerRootView` and uses no gesture handler (the grab handle drags with React
Native's own `PanResponder`), so it cannot conflict with the root view of your own
gestures.

## Quick start

1. Your server mints a native session for the signed-in owner (they last 15 minutes). The
   Nerova API key stays on your server: the app only ever holds the session.

```ts
// Your server, calling the Nerova API (widgets.createSession)
POST https://api.nerova.si/v1/accounts/{accountId}/widgets/sessions
{ "widget": "owner_chat", "platform": "native", "appId": "si.nerova.booking.dev",
  "ownerReference": "user-42", "ownerDisplayName": "Naledi Dlamini" }
// -> { "sessionId": "...", "state": "...", "expiresAt": "...", "url": "..." }
```

A native session has no web origin. It is bound to your app id (the iOS bundle id or
the Android package name), which you register with Nerova like an embed origin, together
with the custom URL schemes (for example `bookingadmin`) and https origins the WhatsApp
connect may return to. Return `sessionId`, `state` and `expiresAt` (or the `url`) to the
app from your own endpoint. The SDK sends them on every call as `X-Widget-Session-Id` and
`X-Widget-State`; there are no cookies and no API key in the app.

2. Mount the provider and the sheet once, as the last child of your root screen.
   `appearance` and `labels` belong on the provider; the sheet takes the layout
   props.

```tsx
import { CompanionProvider, CompanionSheet } from "@nerova/react-native";

export default function App() {
  return (
    <CompanionProvider
      sessionProvider={async () =>
        (await fetch("https://api.example.com/companion/session", { method: "POST" })).json()
      }
      whatsAppReturnUrl="bookingadmin://companion/whatsapp-return"
      appearance={{ colorMode: "system", colors: { primary: "#007AFF" } }}
      onApproval={({ type, approval }) => type === "requested" && updateBadge(approval)}
    >
      <Screens />
      <CompanionSheet restInset={{ right: 16, bottom: 96 }} />
    </CompanionProvider>
  );
}
```

3. Register the deep link scheme (for example `bookingadmin`) in `app.json`, and
   register the app id and the return url with Nerova.

Try it with no server at all:

```tsx
import { CompanionDemo } from "@nerova/react-native/testing";

<CompanionDemo />; // mock API: say "cancel Chloe's colour" or "move Megan"
```

## API

### `<CompanionProvider>`

- `sessionProvider: () => Promise<{ url?, sessionId?, state?, expiresAt? }>`:
  calls your server. The SDK caches the session, refreshes at 80% of its
  lifetime, de-dupes concurrent refreshes, retries once, and recovers from a
  `session_expired` answer by minting a new session and repeating the call.
- `apiBaseUrl?`: defaults to `https://api.nerova.si`, so the SDK calls
  `https://api.nerova.si/v1/companion/*` (the versioned companion API, contract
  `nerova-companion-v1.openapi.json`).
- `api?: "v1" | "legacy"` (default `"v1"`): `"legacy"` calls the owner-chat routes the web
  companion uses (`/api/main/widget/owner-chat/*`) on `https://app.nerova.si` (or the origin
  of the session `url`). `createHttpTransport({ routes })` replaces individual paths.
- `appearance?`: see Appearance. It applies to the sheet and every building block.
- `labels?`: see Labels.
- `onActivity?(activity)`: `"busy"` when the companion starts working on a
  message, `"reply"` when its answer or an approval request is shown, `"idle"`
  when it stopped without a reply (error or stop). Every `busy` is followed by
  exactly one `reply` or `idle`.
- `onTurnDone?({ awaitingReply, awaitingKind })`: a reply finished. `awaitingReply` is
  `true` when the owner has to answer before anything else happens, which is what a voice
  entry uses to keep listening. `awaitingKind` says why: `"approval"` (an approval card to
  decide), `"question"` (the companion asked something), `"confirmation"` (a typed
  confirmation) or `null`. The same value is `useCompanion().lastTurn`. Servers older than
  this version send neither field, so both read as not awaiting.
- `onApproval?({ type, approval })`: `requested`, `approved`, `declined`,
  `expired`, `failed`.
- `onSetupStep?({ step, completed })`: `hello`, `connect_whatsapp`, `review`,
  `test_message`, `live`.
- `onEvent?(event)`: `sheet_opened`, `sheet_closed`, `message_sent`,
  `tool_used`, `whatsapp_connect_started`, `whatsapp_connect_succeeded`,
  `whatsapp_connect_cancelled`, `whatsapp_connect_failed`, `session_refreshed`,
  `error`.
- `whatsAppReturnUrl?`: the deep link the hosted connect page returns to.
- `openAuthSession?(launchUrl, returnUrl)`: replaces `expo-web-browser`.
- `transport?`: replaces the HTTP transport (tests, demos).

**Preload.** Mount the provider and the sheet once in your app shell, at `defaultDetent`
"rest". `initialize()` runs when the provider mounts, independent of the sheet opening: it
prewarms the session, the profile (name, character), the thread, the setup state and
the pending approvals, so the first open is instant. `useCompanion().status` becomes
`"ready"` only after the thread has loaded (it is `"loading"` until then). The thread is
read again each time the app returns to the foreground (together with the approvals).

On unmount the provider aborts requests in flight, stops WhatsApp polling and
clears every timer (session refresh, retries), so Jest exits cleanly.

### `<CompanionSheet>`

The five states from the Companion board: rest (only the avatar), half, sending
(the keyboard is up), full and approval. `sending` and `approval` are derived.

- `detent` / `onDetentChange` / `defaultDetent`: `"rest" | "half" | "full"`.
- `detents?: { half?, full? }`: points. Defaults half 240, full 760 (clamped to
  the screen).
- `draftText` / `onDraftTextChange`: controlled composer text. Setting it fills
  the composer and never sends.
- `context` / `onContextChange`: `{ kind: "appointment", id, summary }`. Shown
  as a removable chip and sent with each message until removed or the sheet
  closes.
- `avatar?: "auto" | "hidden"` and `renderAvatar?({ state, placement, size })`:
  - `avatar="hidden"` hides Nerova's character and draws nothing of its own.
  - `renderAvatar`, when given, replaces Nerova's character and is rendered in
    the same slot (resting avatar, sheet edge or header) with the activity
    `state`, whatever `avatar` is. So `avatar="hidden"` plus `renderAvatar` shows
    only your character. The states, which are the same for `<CompanionAvatar
state>`: - `idle`: nothing is happening. The character breathes and blinks. - `working`: fires from the moment a message is sent until the reply is done,
    stopped or failed (the same span as `onActivity` `busy`). The character hops. - `nod`: fires once, for about 0.9 s, after an approval was approved. - `listening`: never fired by the sheet. It is for your own voice entry:
    render `<CompanionAvatar state="listening">` or your own character yourself
    while you record. `renderAvatar` is typed `RenderAvatarState` (`idle`, `working`, `nod`) and
    never receives `listening`; only `<CompanionAvatar state>` (`AvatarState`) takes it.
    The character also gets a badge with the number of approvals waiting.
  - `avatarAccessibilityLabel` replaces the avatar button's screen reader label.
    By default it is the `avatarButton` label, "{name}, {state}" (for example "Clovie,
    working"), with a hint that says what a tap does ("Open Clovie" or "Close Clovie").
    While the sheet is open the dim overlay is hidden from screen readers when the
    avatar button is present, so only one control announces closing; with no avatar
    button the overlay is the close control, labelled `dismissSheet`.
  - `appearance.characterPlacement: "hidden"` hides every character, including
    `renderAvatar`; the host then opens the sheet through `useCompanion().sheet`.
- `restAvatar?: "shown" | "hidden"`: `"hidden"` hides only the resting avatar, for a host
  that opens the sheet itself (a tab bar button, `useCompanion().sheet.open()`). The edge
  or header character still shows while the sheet is open. A hidden resting avatar, or one
  placed off screen with `restInset`, is removed from screen readers
  (`accessibilityElementsHidden`, `importantForAccessibility="no-hide-descendants"`) and
  receives no touches.
- `welcomeSuggestions?: string[]`: the chips of the welcome card (below).
- `voiceInput?: { autoSend?, language?, vocabulary?, createRecorder? }`: turns on voice input (below).
- `onMicPress?()`: your own recorder, called instead of the SDK one when the mic is tapped. Fill the
  input with `useCompanion().setDraft(text)`, or send with `send`.
- `renderComposerAccessory?({ draftText, setDraft, send })`: a node rendered in place of the mic while the
  input is empty (your own voice control).
- `speech?: boolean` (default `false`): shows the mic while the input is empty, for use with `onMicPress`.
- `fadeWords?: boolean` (default `false`): fade streamed words in (iOS only; see Live generation).
- `manageStatusBar?` (default true): while open, the status bar icons follow the colour
  mode (light icons in dark mode, dark icons in light mode) and are restored on close.
- `suggestions?`: overrides the chips the server sends.
- `autoOpenOnApproval?` (default `true`).
- `restInset?: { right?, bottom? }` (default right 84, bottom 108) and
  `insets?: { top?, bottom? }` for your safe area.
- `onOpen`, `onClose`.
- Ref: `open(detent?)`, `close()`, `focusComposer()`, `setDraftText(text)`.

A closed sheet paints nothing: no dim is rendered at rest (it exists while open and for the
closing animation), and the sheet and the dim are hidden from screen readers, so it steals
no accessibility focus. The dim is always a translucent scrim (40% black), never opaque.
`open()` and `close()` change the sheet state
synchronously, so the animation starts on the next frame with no async work first.

**Empty conversation.** A new conversation shows a welcome card: the character, "Hi, I'm
{name}", one line on what the companion can do, and three suggestion chips ("What's on
today?", "Move a booking", "Who hasn't confirmed?"). Tapping a chip sends it. Change the
chips with `welcomeSuggestions`, and every string with `labels` (`welcomeTitle`,
`welcomeBody`, `welcomeSuggestion1` to `welcomeSuggestion3`).

**Size.** The sheet opens at half and stays at the detent it is in. Sending a message never
expands it to full: it grows only as far as the content needs (up to 60% of the screen) and
goes to full only when the owner drags the grab handle or you call `open("full")`. Height
changes are batched to at most once per 100 ms, never per streamed token.

**Keyboard.** The sheet and the composer ride the keyboard frame on the UI thread
(Reanimated's `useAnimatedKeyboard` with `isStatusBarTranslucentAndroid`): the sheet lifts
by the keyboard height and the composer's bottom padding gives up the safe-area inset as the
keyboard rises, frame by frame, with no JS-side keyboard listener for positioning (a JS
listener only tells the sheet the keyboard went away). Android needs edge-to-edge (the
default from Expo SDK 53) or a window that does not resize for the keyboard; a window that
also resizes would move the sheet twice. Set `insets.bottom` to your navigation bar inset.
I verified this in Jest only, not on a device.

**Composer.** One capsule: the gradient border and the fill share the same frame and radius.
A disabled send is just a dimmed arrow with no background.

**Voice input.** Pass `voiceInput` and the composer has ONE round button on the trailing edge, as in
WhatsApp: the mic while the trimmed input is empty, send as soon as there is text, the mic again when it
is cleared. The icon fades in over 120 ms (not at all with Reduce Motion). Tap the mic to record (it
turns into a red stop button), tap again to stop; the m4a clip is posted to
`POST /v1/companion/transcriptions` with the session headers, and the transcript either fills the input
(`autoSend: false`, the default) or is sent at once (`autoSend: true`). The labels are "Speak to {name}"
and "Send". A recording stops by itself at 60 s. Failures show one inline line: microphone permission
denied (`microphone_denied`), nothing heard (`no_speech`), `transcription_failed`,
`transcription_too_long`, `transcription_credits_unavailable`, or the usual offline/timeout/rate-limit lines.
Recording needs the optional `expo-audio` peer; without it (and without `createRecorder`) the mic is hidden.
For your own recorder pass `onMicPress` (or `renderComposerAccessory`), record yourself and either call
`useCompanion().setDraft(text)` or `createCompanionClient(...).transcribe({ uri }, { language })` for the
text first. `client.transcribe(audio, { language, vocabulary })` returns `{ text, durationMilliseconds, language }`.

**Live generation.** Before the first token the bubble shows a soft three-dot breathing
indicator. The first token renders the moment it arrives: nothing is queued or buffered. The
reply is appended as plain text with a caret, which stays cheap however long it gets
(I measured per-word views at about 40 to 75 ms per token at 200 words against under 1 ms for
plain text, in a test renderer, not on a device). `fadeWords` (iOS only, opt-in, never with
reduced motion) fades each word that arrives in over 60 ms, with no queue; a burst of more
than 8 words in one render appears at once. With reduced motion there is no caret. Tools show only
while they run ("Checking the diary...") and then fold into one subtle line above the answer,
such as "Checked today" or "Checked today \u00b7 3 steps", with no minimum display time.
Internal ids (GUIDs, ULIDs, long hex strings, `bk_...` ids, `id: ...`) are removed from tool
labels and approval texts before they are shown.

**After the owner decides.** The approve, decline and approve-all answers carry `followUp: { text }`
(for example "Done, moved to Sat 15:00."). The sheet shows it at once as the companion's next
message, with no chat call, once per approval (so once per item for approve-all). The server
appends the same line to the thread, and a thread reload replaces the local line instead of
showing it twice.

**New bookings.** The companion also asks before it books: an approval with `kind`
`create_appointment` has a row for the client (name and phone), the service, the date with start and
end ("Fri 16 Oct, 20:30-21:15") and, when chosen, the staff member, each with its own icon. Nothing is
booked until the owner taps Approve, and the follow-up reads "Done, booked for ...". Every card is built
from `title`, `lines` and `consequences` alone, so a kind this version does not know still shows as a
complete card with working buttons (0.1.0-preview.9 shows new bookings that way too).

**Live turns.** The server streams turns as they happen: a tool `start` can arrive before any
text (the row shows, the dots do not), and events can be far apart. The SDK waits up to 90 s
between two events (`chatIdleTimeoutMilliseconds`, never less than 60 s) before it gives up with
a `timeout` error.

### `<CompanionMoment>`

An inline component (not a sheet) for a home screen, under `CompanionProvider`. It shows ONE exchange at a
time: a small "You asked: ..." chip (`colors.userBubble`), then the answer in large type. The lead line streams with a
word fade; booking lists and cards appear when the reply is done. A new request replaces the exchange. Follow-up
suggestions (`done.suggestions`) are never shown. With nothing asked it shows the `idleLine` you pass, or the needs-you queue:

1. pending approvals (compact card: title, one detail line, Approve and Decline, which is a real `decline()`),
2. changes the companion made on its own that can still be undone (the sentence it was told and an "Undo (Ns)" countdown
   that ticks once a second only while the card is on screen),
3. your own `queueItems`.

One item shows at a time with inline buttons; after acting there is a short receipt ("Approved ...", "2 more need you"),
then the next one slides up, and an "N more" chip counts the rest. An exchange that produced cards ends once its last card
was dealt with. Props: `idleLine`, `queueItems: { id, title, detail?, kicker?, actions: { id, label }[], receipt? }[]`,
`onQueueAction(itemId, actionId)`, `renderQueueItem(item, { act })`, `enableUndo` (default `false`: the Undo button is
hidden until the undo route is live; the card and its countdown still show), `voiceInput`, `onMicPress`,
`renderComposerAccessory`, `speech` (as on the sheet; the composer is the same single mic/send button), and
`renderAvatar({ state, placement: "moment", size, blinkToken })`: blink once whenever `blinkToken` changes (on appear,
on a new answer and on a tap). Motion follows the design: the old answer fades up and out, the chip slides in, the answer
staggers, a pressed button scales to 0.97 and morphs into a check, the next item slides up, the mic and send swap in
150 ms. Nothing loops at rest. With Reduce Motion everything crossfades. The `booking` widget renders a list when its
payload is `{ rows: { time, end?, date, clientName?, service?, staff?, status? }[], truncated }` (the server sends it for a schedule or availability turn: up to 20 rows in the business time zone, names only, `status` `scheduled`, `pending` or `unconfirmed`); every widget with its
payload is on `turn.widgets` and on the finished message.

**Actions (act, then undo).** The `action` chat event (`id, kind, status, title, readBack, lines, executedAt, undoUntil,
undoable, undoneAt`) fills `useCompanion().actions` (`executed`, `all`, `undo(id)`, `refresh()`).
`client.listActions()` reads `GET /v1/companion/actions?status=executed` and `client.undoAction(id)` posts
`POST /v1/companion/actions/{id}/undo`. Undo failures are `action_undo_window_closed`, `action_not_undoable`,
`action_undo_failed` and `action_connector_unavailable`.

### `<CompanionSetup>`

The go-live flow inline, for an onboarding screen or a home screen, under `CompanionProvider`: hello, connect WhatsApp,
what the companion found, the test message, live. It uses the same panels as the sheet. Props:

- `onLive()`: called once when the owner finishes the flow in this component (Done after going live, or after
  reconnecting WhatsApp). It is not called when the owner taps Later, or when the owner was already live on mount.
- `children`: rendered instead of the flow while setup is not needed.
- `testID`.

It renders nothing until the setup state has loaded. Give it a container with a bounded height (for example `flex: 1`),
because the panels scroll inside it. `whatsAppReturnUrl` and `openAuthSession` on `CompanionProvider` apply as they do
in the sheet.

```tsx
<CompanionSetup onLive={() => router.replace("/home")}>
  <CompanionMoment />
</CompanionSetup>
```

When WhatsApp is known to be disconnected, setup is needed again and starts at the connect step, even for an owner who
completed setup or whose companion is live. The sheet does the same.

### `useCompanion()`

`status` (`idle | loading | ready | expired | unavailable | offline`), `agent`
(`{ name, bodyType, material }` from the profile), `owner`, `sheet`
(`detent`, `state`, `open()`, `close()`), `messages`, `suggestions`,
`earlierSessions`, `loadEarlierSession(id)`, `turn` (streamed text and tool
steps), `send(text, { context? })`, `retry()`, `stop()`, `activity`,
`draftText`, `setDraftText(text)`, `context`, `setContext()`, `approvals`
(`pending`, `count`, `approve(id)`, `decline(id)`, `approveAll(ids?)`,
`refresh()`), `autonomy`, `whatsapp` (`status`, `phase`, `connect()`,
`refresh()`), `setup` (`step`, `summary`, `load()`, `goTo()`, `goLive()`,
`defer()`), `refreshSession()`.

In the sheet, "Not now" keeps an approval waiting (it stays in
`approvals.pending` for your badge or push); `decline` rejects it on the server.

### Building blocks

- `<CompanionChat>`: message list, composer, suggestion chips, tool rows.
- `<ApprovalCard approval state onApprove onDecline>`: title, from-to rows,
  consequences, Approve and Not now.
- `<CompanionAvatar state size>`: `idle | working | nod | listening`.
- `createCompanionClient({ sessionProvider })`: the same calls without any UI,
  for a notification action that approves without opening the app.

### Appearance

```ts
appearance = {
  colorMode: "light" | "dark" | "system",            // default "system"
  colors: { primary, background, surface, raised, inset, text, textSecondary,
            separator, success, warning, destructive,
            userBubble,        // the owner's bubble (default: inset)
            userBubbleText },  // its text (default: text)
  radii: { sheet: 20, card: 26, control: 26 },
  font: { family: "Inter" | ["Brand Sans", "Inter"], isAvailable?: (family) => boolean },
  spacing: { screenPadding: 20, tapTarget: 44 },
  type: { body: { fontSize: 17, lineHeight: 22 },     // both bubbles, owner and companion (iOS body)
          caption: { fontSize: 15, lineHeight: 20 },  // suggestion chips, context chip
          footnote: { fontSize: 15, lineHeight: 20 }, // meta text: tool rows, status lines
          allowFontScaling: true, maxFontSizeMultiplier: 1.3 },
  depth: "raised" | "flat",
  characterPlacement: "edge" | "header" | "hidden"   // default "edge"
}
```

Text follows the device font size (Dynamic Type) up to `type.maxFontSizeMultiplier`, and the
fixed line heights scale with it. Colours are hex or `rgb()`/`rgba()`; an invalid value falls back to the
default. The theme your server sets when minting the session is merged
underneath: the `appearance` prop wins. `font.family` takes one family or a
list in order of preference: the first available one is used, then the system
font. A family counts as available when it is a system family, when `expo-font`
reports it loaded, or when `expo-font` is not installed. Pass `isAvailable` to
decide yourself.

### Labels

Every string the SDK shows or announces is English by default and can be
replaced with the `labels` prop on `CompanionProvider`. `{name}` is the
companion's name from the profile; other placeholders are named in the text.

```tsx
<CompanionProvider
  labels={{ makeLarger: "Povečaj", closeSheet: "Zapri {name}", askPlaceholder: "Vprašaj {name}...", send: "Pošlji" }}
  ...
/>
```

Keys: `avatarButton` (`{name}`, `{state}`), `avatarStateIdle`, `avatarStateWorking`,
`avatarStateNod`, `avatarStateListening`, `dismissSheet` (the overlay), `openSheet`
and `closeSheet` (the avatar button's hint; `openSheetNoName`, `closeSheetNoName`
and `avatarButtonNoName` while the profile has not loaded), `closeKeyboard`, `makeLarger`, `makeSmaller`,
`waitingBadge`, `autoApproving`, `askPlaceholder`, `workingPlaceholder`, `send`,
`stop`, `retry`, `removeContext`, `working`, `reconnecting`, `offline`,
`unavailable`, the `error*` lines, `approve`, `notNow`, `approving`,
`approvalDone`, `approvalLine`, `needYou`, `approveAll`, `approveAllTitle`,
`approveCount`, `approvedCount`, `back`, the `whatsApp*` and `step*` and
`failure*` lines, the `setup*` lines and the `blocker*` lines. The full list,
with the English text, is `defaultLabels` (exported from the package root and from
`@nerova/react-native/testing`, together with `resolveLabels` and `formatLabel`).

### Errors

Every failure is a `CompanionError` with a stable `code`: `session_expired`,
`session_invalid`, `session_provider_failed`, `origin_not_registered`,
`forbidden`, `not_provisioned`, `account_not_ready`, `connector_unavailable`,
`turn_failed`, `return_url_not_allowed`, `rate_limited`, `validation`,
`message_too_long`, `approval_not_found`, `approval_expired`,
`approval_already_decided`, `approval_connector_conflict`,
`approval_connector_unavailable`, `not_found`, `offline`, `timeout`,
`unavailable`, `stream_interrupted`, `aborted`, `unknown`.
The API's own codes map like this: `companion.session_expired`, `companion.session_invalid`,
`companion.account_not_ready`, `companion.connector_unavailable` (retryable),
`companion.turn_failed` (the `error` event's `retryable` flag says whether sending again
may work), `request.rate_limited` and `activation.return_url_not_allowed`. Each also keeps
`status`, the API's own `serverCode` and `retryAfterSeconds`.

## Testing your app

`@nerova/react-native/testing` has `createMockTransport` and `CompanionDemo`.
`createMockTransport({ setupCompleted: true })` skips the first-run setup so the
composer shows at once; `agent` and `owner` set the profile, and `controls`
expires the session, fails a call or finishes the WhatsApp connect.

For Jest, add the setup file, which mocks `react-native-reanimated`,
`react-native-gesture-handler`, `react-native-svg` and `react-native-webview`
(so `GestureHandlerRootView` needs no `jestSetup` import of its own):

```js
// jest.config.js (jest-expo)
module.exports = {
  preset: "jest-expo",
  setupFilesAfterEnv: ["@nerova/react-native/testing/jest-setup"],
  // jest-expo already has this pattern. The package itself ships transpiled CommonJS; the setup file loads
  // reanimated's own Jest mock, which is TypeScript source, so react-native-reanimated must be transformed.
  transformIgnorePatterns: [
    "node_modules/(?!((jest-)?react-native|@react-native(-community)?)|expo(nent)?|@expo(nent)?/.*|@expo-google-fonts/.*|react-navigation|@react-navigation/.*|@nerova/.*)"
  ]
};
```

If your own tests already mock `react-native-reanimated` (the SDK mock would replace
yours), opt out of that part:

- `@nerova/react-native/testing/jest-setup-minimal`: the same setup without the
  reanimated and worklets mocks (it mocks gesture-handler, svg and webview only).
  Use it as `setupFilesAfterEnv: ["@nerova/react-native/testing/jest-setup-minimal"]`.
- Or keep `jest-setup` and set a flag in a `setupFiles` entry, which runs first:

```js
// jest.flags.js (listed in setupFiles)
globalThis.__NEROVA_SKIP_REANIMATED_MOCK__ = true; // skips the reanimated and worklets mocks
globalThis.__NEROVA_SKIP_GESTURE_HANDLER_MOCK__ = true;
globalThis.__NEROVA_SKIP_SVG_MOCK__ = true;
globalThis.__NEROVA_SKIP_WEBVIEW_MOCK__ = true;
```

## Character

The plush `bot-avatars` character is a 2D canvas library, so it cannot render in
React Native directly. The SDK ships it inside one self-contained page in a
minimal transparent `react-native-webview`, with native hop and nod animations
around it. There is never a flat stand-in. To draw your own character use
`avatar="hidden"` with `renderAvatar`. `scripts/build-avatar-html.mjs` rebuilds
the page from `bot-avatars` (MIT, Jakub Antalik).

## API contract

The SDK implements `nerova-companion-v1.openapi.json`: the routes, the request and
response fields, the `approval` and `error` server-sent events and the error codes. A test
reads that file and checks the SDK against it. Sessions renew themselves: on
`companion.session_expired` (a `401`, or an `error` event) the SDK calls your
`sessionProvider` for a new session and repeats the call once.

WhatsApp connect sends `returnUrl` (`whatsAppReturnUrl`). When the hosted page redirects back
to it with `status=success`, `failure` or `cancelled` (and `sessionId`), the SDK reads the
status from the url `openAuthSession` returns: `success` checks the channel (connected, or
pending while Meta checks the number), `failure` shows "WhatsApp did not finish connecting",
`cancelled` goes back to the start. If the channel is connected anyway, it wins. A return
url the app id does not allow answers `422 activation.return_url_not_allowed`, which the
panel explains.

## Develop

```sh
npm test       # jest (transport, SSE, session, state machine, sheet, labels)
npm run check  # format, lint, types
npm run build && npm pack
```
